package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class SongListAdapter extends RecyclerView.Adapter<SongListAdapter.ViewHolder>{
    private SongListData[] listdata;

    public SongListAdapter(SongListData[] listdata){
        this.listdata = listdata;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.item_song, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        final SongListData listData = listdata[position];
        holder.getAlbumCover().setImageResource(R.drawable.hummingbird);
        holder.getSongName().setText(listData.getSongName());
        holder.getAlbumName().setText(listData.getAlbumName());
        holder.getArtistName().setText(listData.getArtistName());
    }

    @Override
    public int getItemCount() {
        return listdata.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView albumCover;
        public TextView songName;
        public TextView albumName;
        public TextView artistName;

        public ViewHolder(View itemView){
            super(itemView);
            this.albumCover = (ImageView) itemView.findViewById(R.id.albumCover);
            this.songName = (TextView) itemView.findViewById(R.id.songName);
            this.albumName = (TextView) itemView.findViewById(R.id.albumName);
            this.artistName = (TextView) itemView.findViewById(R.id.artistName);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                }
            });
        }

        public ImageView getAlbumCover() {
            return albumCover;
        }

        public void setAlbumCover(ImageView albumCover) {
            this.albumCover = albumCover;
        }

        public TextView getSongName() {
            return songName;
        }

        public void setSongName(TextView songName) {
            this.songName = songName;
        }

        public TextView getAlbumName() {
            return albumName;
        }

        public void setAlbumName(TextView albumName) {
            this.albumName = albumName;
        }

        public TextView getArtistName() {
            return artistName;
        }

        public void setArtistName(TextView artistName) {
            this.artistName = artistName;
        }
    }
}
