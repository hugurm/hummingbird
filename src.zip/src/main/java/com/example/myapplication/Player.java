package com.example.myapplication;

import android.content.Intent;
import android.media.Image;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class Player extends AppCompatActivity {
    MediaPlayer music;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        TextView songInfo = (TextView) findViewById(R.id.songInfo);
        ImageView albumCover = (ImageView) findViewById(R.id.albumCoverLarge);
        Button stopButton = (Button) findViewById(R.id.stopButton);
        Button pauseButton = (Button) findViewById(R.id.pauseButton);
        Button playButton = (Button) findViewById(R.id.playButton);
        Button songList = (Button) findViewById(R.id.songList);

        music = MediaPlayer.create(this, R.raw.sound);

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                musicStop(view);
            }
        });

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                musicPause(view);
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                musicPlay(view);
            }
        });

        songList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listSongs(view);
            }
        });
    }

    void musicPlay(View v){
        music.start();
    }

    void musicPause(View v){
        music.pause();
    }

    void musicStop(View v){
        music.stop();
    }

    void listSongs(View v) {
        Intent intent = new Intent(this, SongList.class);
        startActivity(intent);
    }

}
