package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        final EditText name = (EditText) findViewById(R.id.name_EditText);
        final EditText password = (EditText) findViewById(R.id.password_EditText);
        final EditText surname = (EditText) findViewById(R.id.surname_EditText);
        final EditText phone = (EditText) findViewById(R.id.phone_EditText);
        final EditText email = (EditText) findViewById(R.id.email_EditText);
        final EditText repass = (EditText) findViewById(R.id.password_EditText2);
        final Button signupButton = (Button) findViewById(R.id.signupButton);


        signupButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                User newuser = new User(
                        name.getText().toString(),
                        surname.getText().toString(),
                        password.getText().toString(),
                        email.getText().toString()
                );

                if(password.getText().toString().equals(repass.getText().toString())){
                    if(!LoginActivity.userList.contains(newuser)){
                        if (signupUser(newuser)) {
                            Toast t = Toast.makeText(SignupActivity.this, "Başarılı Kayıt!", Toast.LENGTH_SHORT);
                            t.show();

                            String emailto = email.getText().toString();
                            String emailsubject = "humming bird Kayıt Bilgileriniz";
                            String emailbody = "Ad: " + name.getText().toString() + "\n"
                                    + "Soyad: " + surname.getText().toString() + "\n"
                                    + "Şifre: " + password.getText().toString() + "\n"
                                    + "Telefon Numarası: " + phone.getText().toString() + "\n";

                            Intent emailSend = new Intent(Intent.ACTION_SEND);

                            emailSend.putExtra(Intent.EXTRA_EMAIL, new String[]{emailto});
                            emailSend.putExtra(Intent.EXTRA_SUBJECT, emailsubject);
                            emailSend.putExtra(Intent.EXTRA_TEXT, emailbody);

                            emailSend.setType("message/rfc822");

                            startActivity(Intent.createChooser(emailSend, "Bir mail uygulaması seçiniz:"));
                        } else {
                            Toast t = Toast.makeText(SignupActivity.this, "Başarsız Kayıt...", Toast.LENGTH_SHORT);
                            t.show();
                        }
                    } else {
                        Toast t = Toast.makeText(SignupActivity.this, "Zaten Kayıtlısınız...", Toast.LENGTH_SHORT);
                        t.show();
                        switchToLogin();
                    }
                } else {
                    Toast t = Toast.makeText(SignupActivity.this, "Şifreler Uyuşmuyor...", Toast.LENGTH_SHORT);
                    t.show();
                }
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        switchToLogin();
    }

    public static boolean signupUser(User user){
        try{
            LoginActivity.userList.add(user);
            return true;
        } catch (Exception e){
            return false;
        }

    }

    private void switchToLogin(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

}