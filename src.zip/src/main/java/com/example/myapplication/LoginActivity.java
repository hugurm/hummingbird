package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    int ctr = 0;
    public static ArrayList<User> userList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText username = (EditText) findViewById(R.id.lEmail_EditText);
        final EditText password = (EditText) findViewById(R.id.lPassword_EditText);
        final Button loginButton = (Button) findViewById(R.id.loginButton);
        final Button signupPageButton = (Button) findViewById(R.id.signupPageButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (ctr<2){
                    for (User user:userList){
                        if(user.getEmail().equals(username.getText().toString())){
                            if(user.getPassword().equals(password.getText().toString())){
                                failedLogin(user.getEmail());
                                successfulLogin(user.getEmail());
                                ctr=0;
                            }else{
                                failedLogin("Yanlış Şifre...");
                                ctr++;
                            }
                        }else{
                            failedLogin("Kullanıcı Bulunamadı...");
                            ctr++;
                        }
                    }
                } else {
                    ctr=0;
                    failedLogin("3 kere başarısız giriş...");
                    switchToSignup();
                }
            }
        });

        signupPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToSignup();
            }
        });
    }

    private void successfulLogin(String email){
        Intent intent = new Intent(this, SongList.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }

    private void failedLogin(String reason){
        Toast t = Toast.makeText(LoginActivity.this, reason, Toast.LENGTH_SHORT);
        t.show();
    }

    private void switchToSignup(){
        Intent intent = new Intent(this, SignupActivity.class);
        startActivity(intent);
    }
}