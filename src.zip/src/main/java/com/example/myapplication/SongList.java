package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SongList extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_list);

        SongListData[] mySongList = getAudio(SongList.this);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        SongListAdapter adapter = new SongListAdapter(mySongList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    public SongListData[] getAudio(final Context context){
        ArrayList<SongListData> mySongAL = new ArrayList<>();

        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Audio.AudioColumns.TITLE,
                MediaStore.Audio.AudioColumns.ALBUM,
                MediaStore.Audio.AudioColumns.ARTIST
        };
        Cursor c = context.getContentResolver().query(
                uri,
                projection,
                MediaStore.Audio.Media.DATA + " like ? ",
                new String[]{"%mp3%"},
                "TITLE ASC"
        );

        if (c != null) {
            while (c.moveToNext()) {
                String path = c.getString(0);
                String name = c.getString(1);
                String album = c.getString(2);
                String artist = c.getString(3);

                SongListData song = new SongListData(path, name, album, artist);
                mySongAL.add(song);
            }
            c.close();
        }
        return mySongAL.toArray(new SongListData[0]);
    }

}
